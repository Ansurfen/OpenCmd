---@diagnostic disable: undefined-global
return {
    version = "0.0.1",
    name = "opencmd",
    tag = "",
    load = yock_todo_loader,
}
