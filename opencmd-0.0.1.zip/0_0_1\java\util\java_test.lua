local java = import("./java")
java({
    cp = "./build",
    mainClass = "com.ansurfen.App"
})
